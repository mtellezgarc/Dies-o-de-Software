
package mochila;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Mochila {

    private final float capacidad;
	
    public Mochila(float c){
        capacidad = c;
    }

    private void llenarMochila(Objeto[] objetos){

        Arrays.sort(objetos, new ObjetoComparator());

        float pesoMochila = 0;
        float valorMochila = 0;

        int i = 0;
        int[] solucion = new int[objetos.length];

        while((i < objetos.length) && (pesoMochila + objetos[i].getPeso() <= capacidad)){
                //podemos coger el objeto entero
                pesoMochila += (float)objetos[i].getPeso();
                valorMochila += (float)objetos[i].getValor();
                solucion[i] = i;
                i++;
        }
        if(i <= objetos.length && pesoMochila < capacidad){ //Quedan candidatos por considerar y hay hueco en la mochila
                //Hay que partir el objeto al que apunta i en objetos
                float capacidadRestante = capacidad - pesoMochila;

                valorMochila += (float)objetos[i].getValorPeso() * capacidadRestante;
                pesoMochila = capacidad; //La mochila queda llena después de coger el trozo
        }


        System.out.println("Capacidad de la mochila: " + capacidad);
        System.out.println("Peso de la mochila después del proceso: " + pesoMochila);
        System.out.println("Valor de la mochila después del proceso: " + valorMochila);
        System.out.println("Objetos insertados en la mochila: " + Arrays.toString(objetos));
        for(int j = 0; j < i; j++){
                System.out.print(solucion[j] + " ");
        }
    }

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Introduzca capacidad de la mochila: ");
        float CAPACIDAD  = teclado.nextFloat();
        System.out.print("Introduzca numero de objetos: ");
        int NUM_OBJETOS = teclado.nextInt();

        Objeto[] objetos = new Objeto[NUM_OBJETOS];
        ManejoArchivo archivo=new ManejoArchivo("C:\\Users\\57300\\Documents\\NetBeansProjects\\mochila\\","amochinla.txt");
        ManejoArchivo archivop=new ManejoArchivo("C:\\Users\\57300\\Documents\\NetBeansProjects\\mochila\\","pmochinla.txt");

        float[] pesos = archivop.pesos();
        int[] valores = archivo.numeros();

        for(int i = 0; i < NUM_OBJETOS; i++){
                objetos[i] = new Objeto(pesos[i], valores[i]);
        }

        Mochila mochila = new Mochila(CAPACIDAD);

        mochila.llenarMochila(objetos);
    }
}
