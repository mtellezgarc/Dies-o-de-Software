
package mochila;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Marllytellez
 */
public class ManejoArchivo {
    String ruta;
    String archivo;
    int[] ints;    
    float[] peso;

    public ManejoArchivo(String ruta, String archivo){
        this.ruta=ruta;
        this.archivo=archivo;

    }
    
    public int[] numeros() throws FileNotFoundException, IOException{
        String s1;
        BufferedReader br = new BufferedReader (new FileReader (this.ruta+this.archivo));
        s1 = br.readLine();
        String[] num = s1.split(",");
        this.ints = new int[num.length];
        for (int i = 0; i < num.length; i++) {
            this.ints[i] = Integer.parseInt(num[i]);
        }
        return this.ints;
    }
    
    public float[] pesos() throws FileNotFoundException, IOException{
        String s1;
        BufferedReader br = new BufferedReader (new FileReader (this.ruta+this.archivo));
        s1 = br.readLine();
        String[] num = s1.split(",");
        this.peso = new float[num.length];
        for (int i = 0; i < num.length; i++) {
            this.peso[i] = Float.parseFloat(num[i]);
        }
        return this.peso;
    }
    
    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }
    
    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }
}
